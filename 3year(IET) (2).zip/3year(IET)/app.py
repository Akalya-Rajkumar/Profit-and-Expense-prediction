from flask import Flask, render_template, request, redirect, url_for, jsonify
import pandas as pd
from sklearn.linear_model import LinearRegression
import datetime
import json

app = Flask(__name__)

# In-memory storage
records = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/input', methods=['GET', 'POST'])
def input_record():
    if request.method == 'POST':
        description = request.form.get('description')
        amount = request.form.get('amount')
        type_ = request.form.get('type')
        date_str = request.form.get('date')

        if description and amount and type_ and date_str:
            try:
                amount = float(amount)
                date = datetime.datetime.strptime(date_str, '%Y-%m-%d').date()
                records.append({
                    'description': description,
                    'amount': amount,
                    'type': type_,
                    'date': date
                })
            except ValueError:
                pass  # Invalid data ignored here

        return redirect(url_for('summary'))

    return render_template('input.html')

@app.route('/summary')
def summary():
    total_income = sum(r['amount'] for r in records if r['type'] == 'Income')
    total_expense = sum(r['amount'] for r in records if r['type'] == 'Expense')
    profit = total_income - total_expense

    return render_template('summary.html', records=records,
                           total_income=total_income,
                           total_expense=total_expense,
                           profit=profit)

@app.route('/profit')
def profit():
    # Show buttons for monthly/yearly prediction
    return render_template('profit.html')

def prepare_monthly_data():
    if len(records) < 3:
        return None

    df = pd.DataFrame(records)
    df['date'] = pd.to_datetime(df['date'])
    df['month'] = df['date'].dt.to_period('M')

    monthly = df.groupby(['month', 'type'])['amount'].sum().unstack().fillna(0)
    monthly['profit'] = monthly.get('Income', 0) - monthly.get('Expense', 0)
    monthly = monthly.reset_index()
    monthly['month'] = monthly['month'].astype(str)  # for JSON

    return monthly

def prepare_yearly_data():
    if len(records) < 3:
        return None

    df = pd.DataFrame(records)
    df['date'] = pd.to_datetime(df['date'])
    df['year'] = df['date'].dt.year

    yearly = df.groupby(['year', 'type'])['amount'].sum().unstack().fillna(0)
    yearly['profit'] = yearly.get('Income', 0) - yearly.get('Expense', 0)
    yearly = yearly.reset_index()

    return yearly

@app.route('/predict/monthly')
def predict_monthly():
    monthly = prepare_monthly_data()
    if monthly is None:
        return "Not enough data to predict monthly profit. Please add at least 3 records."

    # Use sequential month index for trend prediction
    monthly['month_num'] = range(1, len(monthly) + 1)

    X = monthly[['month_num']]
    y = monthly['profit']

    model = LinearRegression()
    model.fit(X, y)

    next_month_num = monthly['month_num'].iloc[-1] + 1
    pred_profit = model.predict([[next_month_num]])[0]

    last_month_str = monthly['month'].iloc[-1]
    last_month_date = pd.to_datetime(last_month_str)
    next_month_date = last_month_date + pd.DateOffset(months=1)

    last_6_months = monthly.tail(6)
    chart_labels = list(last_6_months['month']) + [next_month_date.strftime('%Y-%m')]
    chart_data = list(last_6_months['profit']) + [round(pred_profit, 2)]

    return render_template('prediction.html',
                           title="Monthly Profit Prediction",
                           labels=json.dumps(chart_labels),
                           data=json.dumps(chart_data))

@app.route('/predict/yearly')
@app.route('/predict/yearly')
def predict_yearly():
    yearly = prepare_yearly_data()
    if yearly is None:
        return "Not enough data to predict yearly profit. Please add at least 3 records."

    # Add sequential year number for trend
    yearly = yearly.sort_values('year').reset_index(drop=True)
    yearly['year_num'] = range(1, len(yearly) + 1)

    X = yearly[['year_num']]
    y = yearly['profit']

    model = LinearRegression()
    model.fit(X, y)

    last_year_num = yearly['year_num'].iloc[-1]

    preds = []
    labels = []
    for i in range(1, 4):
        next_year_num = last_year_num + i
        pred = model.predict([[next_year_num]])[0]
        preds.append(round(pred, 2))
        labels.append(str(yearly['year'].iloc[-1] + i))

    past_years = list(yearly['year'])
    past_profits = list(yearly['profit'])

    chart_labels = [str(y) for y in past_years] + labels
    chart_data = past_profits + preds

    return render_template('prediction.html',
                           title="Yearly Profit Prediction",
                           labels=json.dumps(chart_labels),
                           data=json.dumps(chart_data))


if __name__ == '__main__':
    app.run(debug=True)
